import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\VisaTypeController::show
 * @see app/Http/Controllers/VisaTypeController.php:11
 * @route '/visa-types/{key}'
 */
export const show = (args: { key: string | number } | [key: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/visa-types/{key}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\VisaTypeController::show
 * @see app/Http/Controllers/VisaTypeController.php:11
 * @route '/visa-types/{key}'
 */
show.url = (args: { key: string | number } | [key: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { key: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    key: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        key: args.key,
                }

    return show.definition.url
            .replace('{key}', parsedArgs.key.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VisaTypeController::show
 * @see app/Http/Controllers/VisaTypeController.php:11
 * @route '/visa-types/{key}'
 */
show.get = (args: { key: string | number } | [key: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\VisaTypeController::show
 * @see app/Http/Controllers/VisaTypeController.php:11
 * @route '/visa-types/{key}'
 */
show.head = (args: { key: string | number } | [key: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\VisaTypeController::show
 * @see app/Http/Controllers/VisaTypeController.php:11
 * @route '/visa-types/{key}'
 */
    const showForm = (args: { key: string | number } | [key: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\VisaTypeController::show
 * @see app/Http/Controllers/VisaTypeController.php:11
 * @route '/visa-types/{key}'
 */
        showForm.get = (args: { key: string | number } | [key: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\VisaTypeController::show
 * @see app/Http/Controllers/VisaTypeController.php:11
 * @route '/visa-types/{key}'
 */
        showForm.head = (args: { key: string | number } | [key: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const VisaTypeController = { show }

export default VisaTypeController