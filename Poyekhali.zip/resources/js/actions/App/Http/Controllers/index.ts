import SiteController from './SiteController'
import ContactController from './ContactController'
import ApplyController from './ApplyController'
import TrackController from './TrackController'
import VisaTypeController from './VisaTypeController'
import Auth from './Auth'
import DashboardController from './DashboardController'
import NotificationController from './NotificationController'
import Admin from './Admin'
const Controllers = {
    SiteController: Object.assign(SiteController, SiteController),
ContactController: Object.assign(ContactController, ContactController),
ApplyController: Object.assign(ApplyController, ApplyController),
TrackController: Object.assign(TrackController, TrackController),
VisaTypeController: Object.assign(VisaTypeController, VisaTypeController),
Auth: Object.assign(Auth, Auth),
DashboardController: Object.assign(DashboardController, DashboardController),
NotificationController: Object.assign(NotificationController, NotificationController),
Admin: Object.assign(Admin, Admin),
}

export default Controllers