import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TrackController::show
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/track',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TrackController::show
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TrackController::show
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TrackController::show
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TrackController::show
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TrackController::show
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TrackController::show
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\TrackController::lookup
 * @see app/Http/Controllers/TrackController.php:17
 * @route '/track'
 */
export const lookup = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: lookup.url(options),
    method: 'post',
})

lookup.definition = {
    methods: ["post"],
    url: '/track',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TrackController::lookup
 * @see app/Http/Controllers/TrackController.php:17
 * @route '/track'
 */
lookup.url = (options?: RouteQueryOptions) => {
    return lookup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TrackController::lookup
 * @see app/Http/Controllers/TrackController.php:17
 * @route '/track'
 */
lookup.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: lookup.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TrackController::lookup
 * @see app/Http/Controllers/TrackController.php:17
 * @route '/track'
 */
    const lookupForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: lookup.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TrackController::lookup
 * @see app/Http/Controllers/TrackController.php:17
 * @route '/track'
 */
        lookupForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: lookup.url(options),
            method: 'post',
        })
    
    lookup.form = lookupForm
const TrackController = { show, lookup }

export default TrackController