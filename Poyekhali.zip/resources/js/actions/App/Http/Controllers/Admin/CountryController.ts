import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CountryController::index
 * @see app/Http/Controllers/Admin/CountryController.php:15
 * @route '/admin/countries'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/countries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CountryController::index
 * @see app/Http/Controllers/Admin/CountryController.php:15
 * @route '/admin/countries'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CountryController::index
 * @see app/Http/Controllers/Admin/CountryController.php:15
 * @route '/admin/countries'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CountryController::index
 * @see app/Http/Controllers/Admin/CountryController.php:15
 * @route '/admin/countries'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CountryController::index
 * @see app/Http/Controllers/Admin/CountryController.php:15
 * @route '/admin/countries'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CountryController::index
 * @see app/Http/Controllers/Admin/CountryController.php:15
 * @route '/admin/countries'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CountryController::index
 * @see app/Http/Controllers/Admin/CountryController.php:15
 * @route '/admin/countries'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\CountryController::create
 * @see app/Http/Controllers/Admin/CountryController.php:22
 * @route '/admin/countries/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/countries/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CountryController::create
 * @see app/Http/Controllers/Admin/CountryController.php:22
 * @route '/admin/countries/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CountryController::create
 * @see app/Http/Controllers/Admin/CountryController.php:22
 * @route '/admin/countries/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CountryController::create
 * @see app/Http/Controllers/Admin/CountryController.php:22
 * @route '/admin/countries/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CountryController::create
 * @see app/Http/Controllers/Admin/CountryController.php:22
 * @route '/admin/countries/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CountryController::create
 * @see app/Http/Controllers/Admin/CountryController.php:22
 * @route '/admin/countries/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CountryController::create
 * @see app/Http/Controllers/Admin/CountryController.php:22
 * @route '/admin/countries/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\CountryController::store
 * @see app/Http/Controllers/Admin/CountryController.php:27
 * @route '/admin/countries'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/countries',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CountryController::store
 * @see app/Http/Controllers/Admin/CountryController.php:27
 * @route '/admin/countries'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CountryController::store
 * @see app/Http/Controllers/Admin/CountryController.php:27
 * @route '/admin/countries'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\CountryController::store
 * @see app/Http/Controllers/Admin/CountryController.php:27
 * @route '/admin/countries'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CountryController::store
 * @see app/Http/Controllers/Admin/CountryController.php:27
 * @route '/admin/countries'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\CountryController::edit
 * @see app/Http/Controllers/Admin/CountryController.php:37
 * @route '/admin/countries/{country}/edit'
 */
export const edit = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/countries/{country}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CountryController::edit
 * @see app/Http/Controllers/Admin/CountryController.php:37
 * @route '/admin/countries/{country}/edit'
 */
edit.url = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { country: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { country: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    country: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        country: typeof args.country === 'object'
                ? args.country.id
                : args.country,
                }

    return edit.definition.url
            .replace('{country}', parsedArgs.country.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CountryController::edit
 * @see app/Http/Controllers/Admin/CountryController.php:37
 * @route '/admin/countries/{country}/edit'
 */
edit.get = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CountryController::edit
 * @see app/Http/Controllers/Admin/CountryController.php:37
 * @route '/admin/countries/{country}/edit'
 */
edit.head = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CountryController::edit
 * @see app/Http/Controllers/Admin/CountryController.php:37
 * @route '/admin/countries/{country}/edit'
 */
    const editForm = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CountryController::edit
 * @see app/Http/Controllers/Admin/CountryController.php:37
 * @route '/admin/countries/{country}/edit'
 */
        editForm.get = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CountryController::edit
 * @see app/Http/Controllers/Admin/CountryController.php:37
 * @route '/admin/countries/{country}/edit'
 */
        editForm.head = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\CountryController::update
 * @see app/Http/Controllers/Admin/CountryController.php:44
 * @route '/admin/countries/{country}'
 */
export const update = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/countries/{country}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\CountryController::update
 * @see app/Http/Controllers/Admin/CountryController.php:44
 * @route '/admin/countries/{country}'
 */
update.url = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { country: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { country: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    country: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        country: typeof args.country === 'object'
                ? args.country.id
                : args.country,
                }

    return update.definition.url
            .replace('{country}', parsedArgs.country.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CountryController::update
 * @see app/Http/Controllers/Admin/CountryController.php:44
 * @route '/admin/countries/{country}'
 */
update.put = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\CountryController::update
 * @see app/Http/Controllers/Admin/CountryController.php:44
 * @route '/admin/countries/{country}'
 */
update.patch = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\CountryController::update
 * @see app/Http/Controllers/Admin/CountryController.php:44
 * @route '/admin/countries/{country}'
 */
    const updateForm = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CountryController::update
 * @see app/Http/Controllers/Admin/CountryController.php:44
 * @route '/admin/countries/{country}'
 */
        updateForm.put = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\CountryController::update
 * @see app/Http/Controllers/Admin/CountryController.php:44
 * @route '/admin/countries/{country}'
 */
        updateForm.patch = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\CountryController::destroy
 * @see app/Http/Controllers/Admin/CountryController.php:54
 * @route '/admin/countries/{country}'
 */
export const destroy = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/countries/{country}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\CountryController::destroy
 * @see app/Http/Controllers/Admin/CountryController.php:54
 * @route '/admin/countries/{country}'
 */
destroy.url = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { country: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { country: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    country: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        country: typeof args.country === 'object'
                ? args.country.id
                : args.country,
                }

    return destroy.definition.url
            .replace('{country}', parsedArgs.country.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CountryController::destroy
 * @see app/Http/Controllers/Admin/CountryController.php:54
 * @route '/admin/countries/{country}'
 */
destroy.delete = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\CountryController::destroy
 * @see app/Http/Controllers/Admin/CountryController.php:54
 * @route '/admin/countries/{country}'
 */
    const destroyForm = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CountryController::destroy
 * @see app/Http/Controllers/Admin/CountryController.php:54
 * @route '/admin/countries/{country}'
 */
        destroyForm.delete = (args: { country: number | { id: number } } | [country: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const CountryController = { index, create, store, edit, update, destroy }

export default CountryController