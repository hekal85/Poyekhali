import AuthController from './AuthController'
import DashboardController from './DashboardController'
import CountryController from './CountryController'
import SubmissionController from './SubmissionController'
import ApplicationController from './ApplicationController'
const Admin = {
    AuthController: Object.assign(AuthController, AuthController),
DashboardController: Object.assign(DashboardController, DashboardController),
CountryController: Object.assign(CountryController, CountryController),
SubmissionController: Object.assign(SubmissionController, SubmissionController),
ApplicationController: Object.assign(ApplicationController, ApplicationController),
}

export default Admin