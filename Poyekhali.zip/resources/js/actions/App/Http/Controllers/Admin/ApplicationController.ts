import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ApplicationController::index
 * @see app/Http/Controllers/Admin/ApplicationController.php:20
 * @route '/admin/applications'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/applications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ApplicationController::index
 * @see app/Http/Controllers/Admin/ApplicationController.php:20
 * @route '/admin/applications'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApplicationController::index
 * @see app/Http/Controllers/Admin/ApplicationController.php:20
 * @route '/admin/applications'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ApplicationController::index
 * @see app/Http/Controllers/Admin/ApplicationController.php:20
 * @route '/admin/applications'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ApplicationController::index
 * @see app/Http/Controllers/Admin/ApplicationController.php:20
 * @route '/admin/applications'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ApplicationController::index
 * @see app/Http/Controllers/Admin/ApplicationController.php:20
 * @route '/admin/applications'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ApplicationController::index
 * @see app/Http/Controllers/Admin/ApplicationController.php:20
 * @route '/admin/applications'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\ApplicationController::show
 * @see app/Http/Controllers/Admin/ApplicationController.php:53
 * @route '/admin/applications/{application}'
 */
export const show = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/applications/{application}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ApplicationController::show
 * @see app/Http/Controllers/Admin/ApplicationController.php:53
 * @route '/admin/applications/{application}'
 */
show.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { application: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    application: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        application: typeof args.application === 'object'
                ? args.application.id
                : args.application,
                }

    return show.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApplicationController::show
 * @see app/Http/Controllers/Admin/ApplicationController.php:53
 * @route '/admin/applications/{application}'
 */
show.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ApplicationController::show
 * @see app/Http/Controllers/Admin/ApplicationController.php:53
 * @route '/admin/applications/{application}'
 */
show.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ApplicationController::show
 * @see app/Http/Controllers/Admin/ApplicationController.php:53
 * @route '/admin/applications/{application}'
 */
    const showForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ApplicationController::show
 * @see app/Http/Controllers/Admin/ApplicationController.php:53
 * @route '/admin/applications/{application}'
 */
        showForm.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ApplicationController::show
 * @see app/Http/Controllers/Admin/ApplicationController.php:53
 * @route '/admin/applications/{application}'
 */
        showForm.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\ApplicationController::updateStatus
 * @see app/Http/Controllers/Admin/ApplicationController.php:63
 * @route '/admin/applications/{application}/status'
 */
export const updateStatus = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStatus.url(args, options),
    method: 'put',
})

updateStatus.definition = {
    methods: ["put"],
    url: '/admin/applications/{application}/status',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\ApplicationController::updateStatus
 * @see app/Http/Controllers/Admin/ApplicationController.php:63
 * @route '/admin/applications/{application}/status'
 */
updateStatus.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { application: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    application: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        application: typeof args.application === 'object'
                ? args.application.id
                : args.application,
                }

    return updateStatus.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApplicationController::updateStatus
 * @see app/Http/Controllers/Admin/ApplicationController.php:63
 * @route '/admin/applications/{application}/status'
 */
updateStatus.put = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStatus.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\ApplicationController::updateStatus
 * @see app/Http/Controllers/Admin/ApplicationController.php:63
 * @route '/admin/applications/{application}/status'
 */
    const updateStatusForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ApplicationController::updateStatus
 * @see app/Http/Controllers/Admin/ApplicationController.php:63
 * @route '/admin/applications/{application}/status'
 */
        updateStatusForm.put = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:88
 * @route '/admin/applications/documents/{document}/download'
 */
export const downloadDocument = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDocument.url(args, options),
    method: 'get',
})

downloadDocument.definition = {
    methods: ["get","head"],
    url: '/admin/applications/documents/{document}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:88
 * @route '/admin/applications/documents/{document}/download'
 */
downloadDocument.url = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { document: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    document: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return downloadDocument.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:88
 * @route '/admin/applications/documents/{document}/download'
 */
downloadDocument.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDocument.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:88
 * @route '/admin/applications/documents/{document}/download'
 */
downloadDocument.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadDocument.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:88
 * @route '/admin/applications/documents/{document}/download'
 */
    const downloadDocumentForm = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadDocument.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:88
 * @route '/admin/applications/documents/{document}/download'
 */
        downloadDocumentForm.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadDocument.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:88
 * @route '/admin/applications/documents/{document}/download'
 */
        downloadDocumentForm.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadDocument.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadDocument.form = downloadDocumentForm
/**
* @see \App\Http\Controllers\Admin\ApplicationController::viewDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:95
 * @route '/admin/applications/documents/{document}/view'
 */
export const viewDocument = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: viewDocument.url(args, options),
    method: 'get',
})

viewDocument.definition = {
    methods: ["get","head"],
    url: '/admin/applications/documents/{document}/view',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ApplicationController::viewDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:95
 * @route '/admin/applications/documents/{document}/view'
 */
viewDocument.url = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { document: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    document: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return viewDocument.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApplicationController::viewDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:95
 * @route '/admin/applications/documents/{document}/view'
 */
viewDocument.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: viewDocument.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ApplicationController::viewDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:95
 * @route '/admin/applications/documents/{document}/view'
 */
viewDocument.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: viewDocument.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ApplicationController::viewDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:95
 * @route '/admin/applications/documents/{document}/view'
 */
    const viewDocumentForm = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: viewDocument.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ApplicationController::viewDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:95
 * @route '/admin/applications/documents/{document}/view'
 */
        viewDocumentForm.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: viewDocument.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ApplicationController::viewDocument
 * @see app/Http/Controllers/Admin/ApplicationController.php:95
 * @route '/admin/applications/documents/{document}/view'
 */
        viewDocumentForm.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: viewDocument.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    viewDocument.form = viewDocumentForm
/**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:104
 * @route '/admin/applications/{application}/receipt/download'
 */
export const downloadReceipt = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadReceipt.url(args, options),
    method: 'get',
})

downloadReceipt.definition = {
    methods: ["get","head"],
    url: '/admin/applications/{application}/receipt/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:104
 * @route '/admin/applications/{application}/receipt/download'
 */
downloadReceipt.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { application: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    application: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        application: typeof args.application === 'object'
                ? args.application.id
                : args.application,
                }

    return downloadReceipt.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:104
 * @route '/admin/applications/{application}/receipt/download'
 */
downloadReceipt.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadReceipt.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:104
 * @route '/admin/applications/{application}/receipt/download'
 */
downloadReceipt.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadReceipt.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:104
 * @route '/admin/applications/{application}/receipt/download'
 */
    const downloadReceiptForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadReceipt.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:104
 * @route '/admin/applications/{application}/receipt/download'
 */
        downloadReceiptForm.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadReceipt.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ApplicationController::downloadReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:104
 * @route '/admin/applications/{application}/receipt/download'
 */
        downloadReceiptForm.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadReceipt.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadReceipt.form = downloadReceiptForm
/**
* @see \App\Http\Controllers\Admin\ApplicationController::viewReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:111
 * @route '/admin/applications/{application}/receipt/view'
 */
export const viewReceipt = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: viewReceipt.url(args, options),
    method: 'get',
})

viewReceipt.definition = {
    methods: ["get","head"],
    url: '/admin/applications/{application}/receipt/view',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ApplicationController::viewReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:111
 * @route '/admin/applications/{application}/receipt/view'
 */
viewReceipt.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { application: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    application: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        application: typeof args.application === 'object'
                ? args.application.id
                : args.application,
                }

    return viewReceipt.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApplicationController::viewReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:111
 * @route '/admin/applications/{application}/receipt/view'
 */
viewReceipt.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: viewReceipt.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ApplicationController::viewReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:111
 * @route '/admin/applications/{application}/receipt/view'
 */
viewReceipt.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: viewReceipt.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ApplicationController::viewReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:111
 * @route '/admin/applications/{application}/receipt/view'
 */
    const viewReceiptForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: viewReceipt.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ApplicationController::viewReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:111
 * @route '/admin/applications/{application}/receipt/view'
 */
        viewReceiptForm.get = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: viewReceipt.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ApplicationController::viewReceipt
 * @see app/Http/Controllers/Admin/ApplicationController.php:111
 * @route '/admin/applications/{application}/receipt/view'
 */
        viewReceiptForm.head = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: viewReceipt.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    viewReceipt.form = viewReceiptForm
const ApplicationController = { index, show, updateStatus, downloadDocument, viewDocument, downloadReceipt, viewReceipt }

export default ApplicationController