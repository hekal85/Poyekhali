import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SubmissionController::index
 * @see app/Http/Controllers/Admin/SubmissionController.php:14
 * @route '/admin/submissions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/submissions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SubmissionController::index
 * @see app/Http/Controllers/Admin/SubmissionController.php:14
 * @route '/admin/submissions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SubmissionController::index
 * @see app/Http/Controllers/Admin/SubmissionController.php:14
 * @route '/admin/submissions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SubmissionController::index
 * @see app/Http/Controllers/Admin/SubmissionController.php:14
 * @route '/admin/submissions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SubmissionController::index
 * @see app/Http/Controllers/Admin/SubmissionController.php:14
 * @route '/admin/submissions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SubmissionController::index
 * @see app/Http/Controllers/Admin/SubmissionController.php:14
 * @route '/admin/submissions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SubmissionController::index
 * @see app/Http/Controllers/Admin/SubmissionController.php:14
 * @route '/admin/submissions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\SubmissionController::show
 * @see app/Http/Controllers/Admin/SubmissionController.php:21
 * @route '/admin/submissions/{submission}'
 */
export const show = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/submissions/{submission}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SubmissionController::show
 * @see app/Http/Controllers/Admin/SubmissionController.php:21
 * @route '/admin/submissions/{submission}'
 */
show.url = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { submission: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { submission: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    submission: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        submission: typeof args.submission === 'object'
                ? args.submission.id
                : args.submission,
                }

    return show.definition.url
            .replace('{submission}', parsedArgs.submission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SubmissionController::show
 * @see app/Http/Controllers/Admin/SubmissionController.php:21
 * @route '/admin/submissions/{submission}'
 */
show.get = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SubmissionController::show
 * @see app/Http/Controllers/Admin/SubmissionController.php:21
 * @route '/admin/submissions/{submission}'
 */
show.head = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SubmissionController::show
 * @see app/Http/Controllers/Admin/SubmissionController.php:21
 * @route '/admin/submissions/{submission}'
 */
    const showForm = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SubmissionController::show
 * @see app/Http/Controllers/Admin/SubmissionController.php:21
 * @route '/admin/submissions/{submission}'
 */
        showForm.get = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SubmissionController::show
 * @see app/Http/Controllers/Admin/SubmissionController.php:21
 * @route '/admin/submissions/{submission}'
 */
        showForm.head = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\SubmissionController::destroy
 * @see app/Http/Controllers/Admin/SubmissionController.php:34
 * @route '/admin/submissions/{submission}'
 */
export const destroy = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/submissions/{submission}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\SubmissionController::destroy
 * @see app/Http/Controllers/Admin/SubmissionController.php:34
 * @route '/admin/submissions/{submission}'
 */
destroy.url = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { submission: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { submission: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    submission: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        submission: typeof args.submission === 'object'
                ? args.submission.id
                : args.submission,
                }

    return destroy.definition.url
            .replace('{submission}', parsedArgs.submission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SubmissionController::destroy
 * @see app/Http/Controllers/Admin/SubmissionController.php:34
 * @route '/admin/submissions/{submission}'
 */
destroy.delete = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\SubmissionController::destroy
 * @see app/Http/Controllers/Admin/SubmissionController.php:34
 * @route '/admin/submissions/{submission}'
 */
    const destroyForm = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SubmissionController::destroy
 * @see app/Http/Controllers/Admin/SubmissionController.php:34
 * @route '/admin/submissions/{submission}'
 */
        destroyForm.delete = (args: { submission: number | { id: number } } | [submission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Admin\SubmissionController::downloadAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:49
 * @route '/admin/submissions/attachments/{attachment}/download'
 */
export const downloadAttachment = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadAttachment.url(args, options),
    method: 'get',
})

downloadAttachment.definition = {
    methods: ["get","head"],
    url: '/admin/submissions/attachments/{attachment}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SubmissionController::downloadAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:49
 * @route '/admin/submissions/attachments/{attachment}/download'
 */
downloadAttachment.url = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attachment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { attachment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    attachment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return downloadAttachment.definition.url
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SubmissionController::downloadAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:49
 * @route '/admin/submissions/attachments/{attachment}/download'
 */
downloadAttachment.get = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadAttachment.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SubmissionController::downloadAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:49
 * @route '/admin/submissions/attachments/{attachment}/download'
 */
downloadAttachment.head = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadAttachment.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SubmissionController::downloadAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:49
 * @route '/admin/submissions/attachments/{attachment}/download'
 */
    const downloadAttachmentForm = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadAttachment.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SubmissionController::downloadAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:49
 * @route '/admin/submissions/attachments/{attachment}/download'
 */
        downloadAttachmentForm.get = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadAttachment.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SubmissionController::downloadAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:49
 * @route '/admin/submissions/attachments/{attachment}/download'
 */
        downloadAttachmentForm.head = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadAttachment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadAttachment.form = downloadAttachmentForm
/**
* @see \App\Http\Controllers\Admin\SubmissionController::viewAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:60
 * @route '/admin/submissions/attachments/{attachment}/view'
 */
export const viewAttachment = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: viewAttachment.url(args, options),
    method: 'get',
})

viewAttachment.definition = {
    methods: ["get","head"],
    url: '/admin/submissions/attachments/{attachment}/view',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SubmissionController::viewAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:60
 * @route '/admin/submissions/attachments/{attachment}/view'
 */
viewAttachment.url = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attachment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { attachment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    attachment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return viewAttachment.definition.url
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SubmissionController::viewAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:60
 * @route '/admin/submissions/attachments/{attachment}/view'
 */
viewAttachment.get = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: viewAttachment.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SubmissionController::viewAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:60
 * @route '/admin/submissions/attachments/{attachment}/view'
 */
viewAttachment.head = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: viewAttachment.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SubmissionController::viewAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:60
 * @route '/admin/submissions/attachments/{attachment}/view'
 */
    const viewAttachmentForm = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: viewAttachment.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SubmissionController::viewAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:60
 * @route '/admin/submissions/attachments/{attachment}/view'
 */
        viewAttachmentForm.get = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: viewAttachment.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SubmissionController::viewAttachment
 * @see app/Http/Controllers/Admin/SubmissionController.php:60
 * @route '/admin/submissions/attachments/{attachment}/view'
 */
        viewAttachmentForm.head = (args: { attachment: number | { id: number } } | [attachment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: viewAttachment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    viewAttachment.form = viewAttachmentForm
const SubmissionController = { index, show, destroy, downloadAttachment, viewAttachment }

export default SubmissionController