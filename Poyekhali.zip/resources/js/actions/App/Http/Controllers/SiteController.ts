import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\SiteController::countriesIndex
 * @see app/Http/Controllers/SiteController.php:21
 * @route '/countries'
 */
export const countriesIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: countriesIndex.url(options),
    method: 'get',
})

countriesIndex.definition = {
    methods: ["get","head"],
    url: '/countries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::countriesIndex
 * @see app/Http/Controllers/SiteController.php:21
 * @route '/countries'
 */
countriesIndex.url = (options?: RouteQueryOptions) => {
    return countriesIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::countriesIndex
 * @see app/Http/Controllers/SiteController.php:21
 * @route '/countries'
 */
countriesIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: countriesIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::countriesIndex
 * @see app/Http/Controllers/SiteController.php:21
 * @route '/countries'
 */
countriesIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: countriesIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::countriesIndex
 * @see app/Http/Controllers/SiteController.php:21
 * @route '/countries'
 */
    const countriesIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: countriesIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::countriesIndex
 * @see app/Http/Controllers/SiteController.php:21
 * @route '/countries'
 */
        countriesIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: countriesIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::countriesIndex
 * @see app/Http/Controllers/SiteController.php:21
 * @route '/countries'
 */
        countriesIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: countriesIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    countriesIndex.form = countriesIndexForm
/**
* @see \App\Http\Controllers\SiteController::countryShow
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/countries/{country}'
 */
export const countryShow = (args: { country: string | number } | [country: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: countryShow.url(args, options),
    method: 'get',
})

countryShow.definition = {
    methods: ["get","head"],
    url: '/countries/{country}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::countryShow
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/countries/{country}'
 */
countryShow.url = (args: { country: string | number } | [country: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { country: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    country: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        country: args.country,
                }

    return countryShow.definition.url
            .replace('{country}', parsedArgs.country.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::countryShow
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/countries/{country}'
 */
countryShow.get = (args: { country: string | number } | [country: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: countryShow.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::countryShow
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/countries/{country}'
 */
countryShow.head = (args: { country: string | number } | [country: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: countryShow.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::countryShow
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/countries/{country}'
 */
    const countryShowForm = (args: { country: string | number } | [country: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: countryShow.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::countryShow
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/countries/{country}'
 */
        countryShowForm.get = (args: { country: string | number } | [country: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: countryShow.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::countryShow
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/countries/{country}'
 */
        countryShowForm.head = (args: { country: string | number } | [country: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: countryShow.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    countryShow.form = countryShowForm
/**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
export const contact = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})

contact.definition = {
    methods: ["get","head"],
    url: '/contact',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
contact.url = (options?: RouteQueryOptions) => {
    return contact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
contact.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
contact.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contact.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
    const contactForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: contact.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
        contactForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contact.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
        contactForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contact.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    contact.form = contactForm
/**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
export const apply = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apply.url(options),
    method: 'get',
})

apply.definition = {
    methods: ["get","head"],
    url: '/apply',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
apply.url = (options?: RouteQueryOptions) => {
    return apply.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
apply.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apply.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
apply.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: apply.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
    const applyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: apply.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
        applyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apply.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
        applyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apply.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    apply.form = applyForm
const SiteController = { home, countriesIndex, countryShow, contact, apply }

export default SiteController