import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\TrackController::lookup
 * @see app/Http/Controllers/TrackController.php:17
 * @route '/track'
 */
export const lookup = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: lookup.url(options),
    method: 'post',
})

lookup.definition = {
    methods: ["post"],
    url: '/track',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TrackController::lookup
 * @see app/Http/Controllers/TrackController.php:17
 * @route '/track'
 */
lookup.url = (options?: RouteQueryOptions) => {
    return lookup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TrackController::lookup
 * @see app/Http/Controllers/TrackController.php:17
 * @route '/track'
 */
lookup.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: lookup.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TrackController::lookup
 * @see app/Http/Controllers/TrackController.php:17
 * @route '/track'
 */
    const lookupForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: lookup.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TrackController::lookup
 * @see app/Http/Controllers/TrackController.php:17
 * @route '/track'
 */
        lookupForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: lookup.url(options),
            method: 'post',
        })
    
    lookup.form = lookupForm
const track = {
    lookup: Object.assign(lookup, lookup),
}

export default track