import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../wayfinder'
/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:13
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
export const contact = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})

contact.definition = {
    methods: ["get","head"],
    url: '/contact',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
contact.url = (options?: RouteQueryOptions) => {
    return contact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
contact.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
contact.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contact.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
    const contactForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: contact.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
        contactForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contact.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::contact
 * @see app/Http/Controllers/SiteController.php:37
 * @route '/contact'
 */
        contactForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contact.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    contact.form = contactForm
/**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
export const apply = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apply.url(options),
    method: 'get',
})

apply.definition = {
    methods: ["get","head"],
    url: '/apply',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
apply.url = (options?: RouteQueryOptions) => {
    return apply.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
apply.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apply.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
apply.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: apply.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
    const applyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: apply.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
        applyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apply.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::apply
 * @see app/Http/Controllers/SiteController.php:44
 * @route '/apply'
 */
        applyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apply.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    apply.form = applyForm
/**
* @see \App\Http\Controllers\TrackController::track
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
export const track = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track.url(options),
    method: 'get',
})

track.definition = {
    methods: ["get","head"],
    url: '/track',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TrackController::track
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
track.url = (options?: RouteQueryOptions) => {
    return track.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TrackController::track
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
track.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TrackController::track
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
track.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: track.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TrackController::track
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
    const trackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: track.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TrackController::track
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
        trackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: track.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TrackController::track
 * @see app/Http/Controllers/TrackController.php:12
 * @route '/track'
 */
        trackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: track.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    track.form = trackForm
/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::login
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:17
 * @route '/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::login
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:17
 * @route '/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::login
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:17
 * @route '/login'
 */
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::login
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:17
 * @route '/login'
 */
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\CustomerAuthController::login
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:17
 * @route '/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: login.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\CustomerAuthController::login
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:17
 * @route '/login'
 */
        loginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\CustomerAuthController::login
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:17
 * @route '/login'
 */
        loginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::register
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:38
 * @route '/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::register
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:38
 * @route '/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::register
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:38
 * @route '/register'
 */
register.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::register
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:38
 * @route '/register'
 */
register.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\CustomerAuthController::register
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:38
 * @route '/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: register.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\CustomerAuthController::register
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:38
 * @route '/register'
 */
        registerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\CustomerAuthController::register
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:38
 * @route '/register'
 */
        registerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    register.form = registerForm
/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::logout
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:63
 * @route '/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::logout
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:63
 * @route '/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\CustomerAuthController::logout
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:63
 * @route '/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\CustomerAuthController::logout
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:63
 * @route '/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\CustomerAuthController::logout
 * @see app/Http/Controllers/Auth/CustomerAuthController.php:63
 * @route '/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:13
 * @route '/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:13
 * @route '/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:13
 * @route '/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:13
 * @route '/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:13
 * @route '/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:13
 * @route '/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:13
 * @route '/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm