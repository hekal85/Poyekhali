<script setup lang="ts">
import { Head, Link } from '@inertiajs/vue3';
import AdminLayout from '../../../Layouts/AdminLayout.vue';

interface Application {
    id: number;
    order_number: string;
    name: string;
    passport_number: string;
    phone: string;
    status: string;
    country: { name_ar: string; name_en: string };
    visa_type: { name_ar: string; name_en: string };
    created_at: string;
}

defineProps<{
    applications: { data: Application[]; links: { url: string | null; label: string; active: boolean }[] };
}>();

const statusLabels: Record<string, string> = {
    under_review: 'تحت الدراسة',
    approved_processing: 'جارٍ الاستخراج',
    visa_ready: 'التأشيرة جاهزة',
    visa_cancelled: 'ملغاة',
    deleted: 'محذوف',
    other: 'أخرى',
};

const statusStyles: Record<string, string> = {
    under_review: 'bg-brass/15 text-brass',
    approved_processing: 'bg-teal/15 text-teal',
    visa_ready: 'bg-teal text-white',
    visa_cancelled: 'bg-alert/15 text-alert',
    deleted: 'bg-ink/10 text-ink/50',
    other: 'bg-ink/10 text-ink/60',
};
</script>

<template>
    <Head title="طلبات التأشيرات" />

    <AdminLayout>
        <h1 class="font-display text-2xl font-extrabold text-ink">طلبات التأشيرات</h1>

        <div class="mt-6 overflow-hidden rounded-2xl bg-white shadow-sm shadow-ink/5">
            <table class="w-full text-sm">
                <thead class="bg-paper text-xs text-ink/50">
                    <tr>
                        <th class="px-5 py-3 text-start font-medium">رقم الطلب</th>
                        <th class="px-5 py-3 text-start font-medium">الاسم</th>
                        <th class="px-5 py-3 text-start font-medium">الدولة / نوع التأشيرة</th>
                        <th class="px-5 py-3 text-start font-medium">الحالة</th>
                        <th class="px-5 py-3 text-start font-medium">التاريخ</th>
                        <th class="px-5 py-3"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-paper-dark">
                    <tr v-for="a in applications.data" :key="a.id">
                        <td class="px-5 py-3 font-bold text-ink" dir="ltr">{{ a.order_number }}</td>
                        <td class="px-5 py-3 text-ink">
                            {{ a.name }}
                            <div class="text-xs text-ink/40" dir="ltr">{{ a.passport_number }}</div>
                        </td>
                        <td class="px-5 py-3 text-ink/60">{{ a.country.name_ar }} — {{ a.visa_type.name_ar }}</td>
                        <td class="px-5 py-3">
                            <span class="rounded-full px-2.5 py-1 text-xs font-bold" :class="statusStyles[a.status] ?? statusStyles.other">
                                {{ statusLabels[a.status] ?? a.status }}
                            </span>
                        </td>
                        <td class="px-5 py-3 text-ink/40">{{ new Date(a.created_at).toLocaleDateString('ar-EG') }}</td>
                        <td class="px-5 py-3 text-end">
                            <Link :href="`/admin/applications/${a.id}`" class="font-medium text-teal hover:underline">عرض</Link>
                        </td>
                    </tr>
                    <tr v-if="!applications.data.length">
                        <td colspan="6" class="px-5 py-10 text-center text-ink/40">لسه مفيش طلبات</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="mt-4 flex flex-wrap gap-2">
            <Link
                v-for="(link, i) in applications.links"
                :key="i"
                :href="link.url ?? ''"
                v-html="link.label"
                class="rounded-lg px-3 py-1.5 text-sm"
                :class="link.active ? 'bg-teal text-white' : 'bg-white text-ink/60 hover:bg-paper-dark'"
            />
        </div>
    </AdminLayout>
</template>
