<?php

namespace App\Http\Controllers;

use App\Models\Country;
use Inertia\Inertia;
use Inertia\Response;

class SiteController extends Controller
{
    public function home(): Response
    {
        return Inertia::render('Home', [
            'countries' => $this->activeCountries(),
        ]);
    }

    public function countriesIndex(): Response
    {
        return Inertia::render('Countries/Index', [
            'countries' => $this->activeCountries(),
        ]);
    }

    public function countryShow(string $country): Response
    {
        $model = Country::where('slug', $country)->where('is_active', true)->firstOrFail();

        return Inertia::render('Countries/Show', [
            'country' => $model->toFrontend(),
        ]);
    }

    public function contact(): Response
    {
        return Inertia::render('Contact', [
            'countries' => $this->activeCountries(),
        ]);
    }

    public function apply(): Response
    {
        return Inertia::render('Apply', [
            'countries' => $this->activeCountries(),
        ]);
    }

    private function activeCountries()
    {
        return Country::where('is_active', true)
            ->orderBy('order')
            ->get()
            ->map->toFrontend()
            ->values();
    }
}
