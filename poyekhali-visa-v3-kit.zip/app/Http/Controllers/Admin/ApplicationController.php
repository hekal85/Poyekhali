<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Application;
use App\Models\ApplicationDocument;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class ApplicationController extends Controller
{
    public function index(): Response
    {
        return Inertia::render('admin/Applications/Index', [
            'applications' => Application::with(['country', 'visaType'])->latest()->paginate(15),
        ]);
    }

    public function show(Application $application): Response
    {
        $application->load(['country', 'visaType', 'documents']);

        return Inertia::render('admin/Applications/Show', [
            'application' => $application,
            'statuses' => Application::STATUSES,
        ]);
    }

    public function updateStatus(Request $request, Application $application)
    {
        $validated = $request->validate([
            'status' => ['required', Rule::in(Application::STATUSES)],
        ]);

        $application->update($validated);

        return back()->with('success', 'تم تحديث حالة الطلب.');
    }

    public function downloadDocument(ApplicationDocument $document)
    {
        abort_unless(Storage::disk('public')->exists($document->path), 404);

        return Storage::disk('public')->download($document->path, $document->original_name);
    }

    public function viewDocument(ApplicationDocument $document)
    {
        abort_unless(Storage::disk('public')->exists($document->path), 404);

        return Storage::disk('public')->response($document->path, $document->original_name, [
            'Content-Disposition' => 'inline; filename="' . $document->original_name . '"',
        ]);
    }

    public function downloadReceipt(Application $application)
    {
        abort_unless($application->payment_receipt_path && Storage::disk('public')->exists($application->payment_receipt_path), 404);

        return Storage::disk('public')->download($application->payment_receipt_path, "receipt-{$application->order_number}");
    }

    public function viewReceipt(Application $application)
    {
        abort_unless($application->payment_receipt_path && Storage::disk('public')->exists($application->payment_receipt_path), 404);

        return Storage::disk('public')->response($application->payment_receipt_path, "receipt-{$application->order_number}", [
            'Content-Disposition' => 'inline; filename="receipt-' . $application->order_number . '"',
        ]);
    }
}
