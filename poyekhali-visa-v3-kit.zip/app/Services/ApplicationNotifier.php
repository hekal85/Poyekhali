<?php

namespace App\Services;

use App\Mail\ApplicationReceived;
use App\Models\Application;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;

/**
 * بيبعت إشعار "تم استلام طلبك" على كل قناة متاحة (إيميل / تيليجرام / واتساب).
 * كل قناة مستقلة عن التانية - لو واحدة فشلت أو مش متظبطة، الباقي بيشتغل عادي
 * والطلب نفسه بيتحفظ في قاعدة البيانات في كل الحالات.
 */
class ApplicationNotifier
{
    public function notify(Application $application): void
    {
        $this->sendEmail($application);
        $this->sendTelegram($application);
        $this->sendWhatsapp($application);
    }

    private function message(Application $application): string
    {
        return "تحية طيبة {$application->name}،\n\n"
            . "تم استلام طلبك بنجاح برقم: {$application->order_number}\n"
            . "الدولة: {$application->country->name_ar}\n"
            . "نوع التأشيرة: {$application->visaType->name_ar}\n\n"
            . "تقدر تتابع حالة طلبك في أي وقت من صفحة \"تتبع حالة الطلب\" على الموقع "
            . "برقم الطلب ورقم جواز السفر.\n\n"
            . "فريق بيخالي (Poyekhali)";
    }

    private function sendEmail(Application $application): void
    {
        if (! $application->email) {
            return;
        }

        try {
            Mail::to($application->email)->send(new ApplicationReceived($application));
        } catch (\Throwable $e) {
            report($e);
        }
    }

    private function sendTelegram(Application $application): void
    {
        $token = config('notifications.telegram.bot_token');
        $chatId = config('notifications.telegram.chat_id');

        if (! $token || ! $chatId) {
            return; // البوت مش متظبط - تجاهل من غير ما توقف باقي الإشعارات
        }

        try {
            Http::timeout(8)->post("https://api.telegram.org/bot{$token}/sendMessage", [
                'chat_id' => $chatId,
                'text' => $this->message($application),
            ]);
        } catch (\Throwable $e) {
            report($e);
        }
    }

    private function sendWhatsapp(Application $application): void
    {
        $url = config('notifications.whatsapp.api_url');
        $token = config('notifications.whatsapp.api_token');

        if (! $url || ! $token || ! $application->phone) {
            return; // مفيش حساب WhatsApp Business API متظبط
        }

        try {
            Http::timeout(8)->withToken($token)->post($url, [
                'to' => $application->phone,
                'body' => $this->message($application),
            ]);
        } catch (\Throwable $e) {
            report($e);
        }
    }
}
