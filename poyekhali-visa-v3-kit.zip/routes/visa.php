<?php

use App\Http\Controllers\ApplyController;
use App\Http\Controllers\Auth\CustomerAuthController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\SiteController;
use App\Http\Controllers\TrackController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| راوتات الموقع العام - محملة تلقائيًا عبر require __DIR__.'/visa.php' جوه web.php
|--------------------------------------------------------------------------
*/

Route::get('/', [SiteController::class, 'home'])->name('home');
Route::get('/countries', [SiteController::class, 'countriesIndex'])->name('countries.index');
Route::get('/countries/{country}', [SiteController::class, 'countryShow'])->name('countries.show');

Route::get('/contact', [SiteController::class, 'contact'])->name('contact');
Route::post('/contact', [ContactController::class, 'store'])->name('contact.store');

Route::get('/apply', [SiteController::class, 'apply'])->name('apply');
Route::post('/apply', [ApplyController::class, 'store'])->name('apply.store');

Route::get('/track', [TrackController::class, 'show'])->name('track');
Route::post('/track', [TrackController::class, 'lookup'])->name('track.lookup');

// ملحوظة: تبديل اللغة بيتم بالكامل من جانب المتصفح (vue-i18n + localStorage)،
// من غير ما نحتاج نبعت أي حاجة للسيرفر.

// دخول/تسجيل العملاء (مختلف عن /admin)
Route::middleware('guest')->group(function () {
    Route::get('/login', [CustomerAuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [CustomerAuthController::class, 'login']);
    Route::get('/register', [CustomerAuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [CustomerAuthController::class, 'register']);
});
Route::middleware('auth')->post('/logout', [CustomerAuthController::class, 'logout'])->name('logout');

require __DIR__ . '/admin.php';
